from time import sleep

for i in range(99, 1, -1):
    print(i)
    sleep(1)
